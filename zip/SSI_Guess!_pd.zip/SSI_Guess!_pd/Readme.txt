SSI April 2021
Roman & Jia

Readme instructions

Steps
1. Open SSI-Main
2. Press red button to start
3. If you have 6 speakers, skip next step
4. If you have 2 speakers press test, this will set ouput to 2 speakers
in order from 1 to 6
5. Use the green slider to simulate the microbit compass Midi input
6. Use the green button to confirm it's direction
7. The order will be displayd under the random_arr

Good Luck!!
